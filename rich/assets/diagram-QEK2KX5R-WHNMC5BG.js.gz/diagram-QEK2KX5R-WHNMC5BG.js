import{a as E}from"./chunk-FKI57LWF.js";import{a as F}from"./chunk-VLA6Y5Q7.js";import"./chunk-XNTNLEAE.js";import"./chunk-DWH46MSL.js";import"./chunk-C2U2UT7U.js";import"./chunk-R7U46GLO.js";import"./chunk-WB5YKMB6.js";import"./chunk-T3NANBBB.js";import{a as I}from"./chunk-2A4CFDLY.js";import{C as y}from"./chunk-ZFGHIKX6.js";import"./chunk-D54EBC4I.js";import"./chunk-5YB7VN23.js";import{P as A,Q as L,R as T,S as O,T as S,U as k,V as R,o as b,q as M,y as C}from"./chunk-BYNIZFGG.js";import{b as o,d as w}from"./chunk-CBCPGTYA.js";import"./chunk-YWCARGXI.js";import"./chunk-ZULQ5H7A.js";import"./chunk-FIEHKGF6.js";import"./chunk-SUN732H5.js";import"./chunk-APEPCRIB.js";var h={showLegend:!0,ticks:5,max:null,min:0,graticule:"circle"},_={axes:[],curves:[],options:h},m=structuredClone(_),H=M.radar,j=o(()=>y({...H,...C().radar}),"getConfig"),D=o(()=>m.axes,"getAxes"),N=o(()=>m.curves,"getCurves"),U=o(()=>m.options,"getOptions"),X=o(a=>{m.axes=a.map(t=>({name:t.name,label:t.label??t.name}))},"setAxes"),Y=o(a=>{m.curves=a.map(t=>({name:t.name,label:t.label??t.name,entries:Z(t.entries)}))},"setCurves"),Z=o(a=>{if(a[0].axis==null)return a.map(e=>e.value);let t=D();if(t.length===0)throw new Error("Axes must be populated before curves for reference entries");return t.map(e=>{let r=a.find(n=>n.axis?.$refText===e.name);if(r===void 0)throw new Error("Missing entry for axis "+e.label);return r.value})},"computeCurveEntries"),q=o(a=>{let t=a.reduce((e,r)=>(e[r.name]=r,e),{});m.options={showLegend:t.showLegend?.value??h.showLegend,ticks:t.ticks?.value??h.ticks,max:t.max?.value??h.max,min:t.min?.value??h.min,graticule:t.graticule?.value??h.graticule}},"setOptions"),J=o(()=>{A(),m=structuredClone(_)},"clear"),$={getAxes:D,getCurves:N,getOptions:U,setAxes:X,setCurves:Y,setOptions:q,getConfig:j,clear:J,setAccTitle:L,getAccTitle:T,setDiagramTitle:k,getDiagramTitle:R,getAccDescription:S,setAccDescription:O},K=o(a=>{E(a,$);let{axes:t,curves:e,options:r}=a;$.setAxes(t),$.setCurves(e),$.setOptions(r)},"populate"),Q={parse:o(async a=>{let t=await F("radar",a);w.debug(t),K(t)},"parse")},tt=o((a,t,e,r)=>{let n=r.db,i=n.getAxes(),l=n.getCurves(),s=n.getOptions(),c=n.getConfig(),d=n.getDiagramTitle(),p=I(t),u=et(p,c),g=s.max??Math.max(...l.map(f=>Math.max(...f.entries))),x=s.min,v=Math.min(c.width,c.height)/2;at(u,i,v,s.ticks,s.graticule),rt(u,i,v,c),G(u,i,l,x,g,s.graticule,c),V(u,l,s.showLegend,c),u.append("text").attr("class","radarTitle").text(d).attr("x",0).attr("y",-c.height/2-c.marginTop)},"draw"),et=o((a,t)=>{let e=t.width+t.marginLeft+t.marginRight,r=t.height+t.marginTop+t.marginBottom,n={x:t.marginLeft+t.width/2,y:t.marginTop+t.height/2};return a.attr("viewbox",`0 0 ${e} ${r}`).attr("width",e).attr("height",r),a.append("g").attr("transform",`translate(${n.x}, ${n.y})`)},"drawFrame"),at=o((a,t,e,r,n)=>{if(n==="circle")for(let i=0;i<r;i++){let l=e*(i+1)/r;a.append("circle").attr("r",l).attr("class","radarGraticule")}else if(n==="polygon"){let i=t.length;for(let l=0;l<r;l++){let s=e*(l+1)/r,c=t.map((d,p)=>{let u=2*p*Math.PI/i-Math.PI/2,g=s*Math.cos(u),x=s*Math.sin(u);return`${g},${x}`}).join(" ");a.append("polygon").attr("points",c).attr("class","radarGraticule")}}},"drawGraticule"),rt=o((a,t,e,r)=>{let n=t.length;for(let i=0;i<n;i++){let l=t[i].label,s=2*i*Math.PI/n-Math.PI/2;a.append("line").attr("x1",0).attr("y1",0).attr("x2",e*r.axisScaleFactor*Math.cos(s)).attr("y2",e*r.axisScaleFactor*Math.sin(s)).attr("class","radarAxisLine"),a.append("text").text(l).attr("x",e*r.axisLabelFactor*Math.cos(s)).attr("y",e*r.axisLabelFactor*Math.sin(s)).attr("class","radarAxisLabel")}},"drawAxes");function G(a,t,e,r,n,i,l){let s=t.length,c=Math.min(l.width,l.height)/2;e.forEach((d,p)=>{if(d.entries.length!==s)return;let u=d.entries.map((g,x)=>{let v=2*Math.PI*x/s-Math.PI/2,f=P(g,r,n,c),W=f*Math.cos(v),B=f*Math.sin(v);return{x:W,y:B}});i==="circle"?a.append("path").attr("d",z(u,l.curveTension)).attr("class",`radarCurve-${p}`):i==="polygon"&&a.append("polygon").attr("points",u.map(g=>`${g.x},${g.y}`).join(" ")).attr("class",`radarCurve-${p}`)})}o(G,"drawCurves");function P(a,t,e,r){let n=Math.min(Math.max(a,t),e);return r*(n-t)/(e-t)}o(P,"relativeRadius");function z(a,t){let e=a.length,r=`M${a[0].x},${a[0].y}`;for(let n=0;n<e;n++){let i=a[(n-1+e)%e],l=a[n],s=a[(n+1)%e],c=a[(n+2)%e],d={x:l.x+(s.x-i.x)*t,y:l.y+(s.y-i.y)*t},p={x:s.x-(c.x-l.x)*t,y:s.y-(c.y-l.y)*t};r+=` C${d.x},${d.y} ${p.x},${p.y} ${s.x},${s.y}`}return`${r} Z`}o(z,"closedRoundCurve");function V(a,t,e,r){if(!e)return;let n=(r.width/2+r.marginRight)*3/4,i=-(r.height/2+r.marginTop)*3/4,l=20;t.forEach((s,c)=>{let d=a.append("g").attr("transform",`translate(${n}, ${i+c*l})`);d.append("rect").attr("width",12).attr("height",12).attr("class",`radarLegendBox-${c}`),d.append("text").attr("x",16).attr("y",0).attr("class","radarLegendText").text(s.label)})}o(V,"drawLegend");var nt={draw:tt},st=o((a,t)=>{let e="";for(let r=0;r<a.THEME_COLOR_LIMIT;r++){let n=a[`cScale${r}`];e+=`
		.radarCurve-${r} {
			color: ${n};
			fill: ${n};
			fill-opacity: ${t.curveOpacity};
			stroke: ${n};
			stroke-width: ${t.curveStrokeWidth};
		}
		.radarLegendBox-${r} {
			fill: ${n};
			fill-opacity: ${t.curveOpacity};
			stroke: ${n};
		}
		`}return e},"genIndexStyles"),ot=o(a=>{let t=b(),e=C(),r=y(t,e.themeVariables),n=y(r.radar,a);return{themeVariables:r,radarOptions:n}},"buildRadarStyleOptions"),it=o(({radar:a}={})=>{let{themeVariables:t,radarOptions:e}=ot(a);return`
	.radarTitle {
		font-size: ${t.fontSize};
		color: ${t.titleColor};
		dominant-baseline: hanging;
		text-anchor: middle;
	}
	.radarAxisLine {
		stroke: ${e.axisColor};
		stroke-width: ${e.axisStrokeWidth};
	}
	.radarAxisLabel {
		dominant-baseline: middle;
		text-anchor: middle;
		font-size: ${e.axisLabelFontSize}px;
		color: ${e.axisColor};
	}
	.radarGraticule {
		fill: ${e.graticuleColor};
		fill-opacity: ${e.graticuleOpacity};
		stroke: ${e.graticuleColor};
		stroke-width: ${e.graticuleStrokeWidth};
	}
	.radarLegendText {
		text-anchor: start;
		font-size: ${e.legendFontSize}px;
		dominant-baseline: hanging;
	}
	${st(t,e)}
	`},"styles"),mt={parser:Q,db:$,renderer:nt,styles:it};export{mt as diagram};
