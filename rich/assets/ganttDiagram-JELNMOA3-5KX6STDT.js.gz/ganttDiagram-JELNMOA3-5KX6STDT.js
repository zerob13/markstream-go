import{a as be,b as Te,f as xe,i as It,j as At,k as $t,l as Ft,m as Lt,n as we,o as _e,p as De,q as Se,r as Me,s as Ce,t as Ee,u as Wt,v as Ot,y as Ye,z as Ie}from"./chunk-GZNHMA23.js";import{D as Ae}from"./chunk-ZFGHIKX6.js";import{a as ri}from"./chunk-D54EBC4I.js";import"./chunk-5YB7VN23.js";import{K as de,L as fe,P as he,Q as me,R as ke,S as ye,T as ge,U as pe,V as ve,W as ot}from"./chunk-BYNIZFGG.js";import{a as ue,b as c,d as it,f as yt}from"./chunk-CBCPGTYA.js";import"./chunk-SUN732H5.js";import{a as xt,d as at}from"./chunk-APEPCRIB.js";var Oe=xt((zt,Nt)=>{(function(t,i){typeof zt=="object"&&typeof Nt<"u"?Nt.exports=i():typeof define=="function"&&define.amd?define(i):(t=typeof globalThis<"u"?globalThis:t||self).dayjs_plugin_isoWeek=i()})(zt,(function(){"use strict";var t="day";return function(i,s,a){var n=function(S){return S.add(4-S.isoWeekday(),t)},l=s.prototype;l.isoWeekYear=function(){return n(this).year()},l.isoWeek=function(S){if(!this.$utils().u(S))return this.add(7*(S-this.isoWeek()),t);var w,L,E,V,I=n(this),M=(w=this.isoWeekYear(),L=this.$u,E=(L?a.utc:a)().year(w).startOf("year"),V=4-E.isoWeekday(),E.isoWeekday()>4&&(V+=7),E.add(V,t));return I.diff(M,"week")+1},l.isoWeekday=function(S){return this.$utils().u(S)?this.day()||7:this.day(this.day()%7?S:S-7)};var k=l.startOf;l.startOf=function(S,w){var L=this.$utils(),E=!!L.u(w)||w;return L.p(S)==="isoweek"?E?this.date(this.date()-(this.isoWeekday()-1)).startOf("day"):this.date(this.date()-1-(this.isoWeekday()-1)+7).endOf("day"):k.bind(this)(S,w)}}}))});var Ve=xt((Ht,Rt)=>{(function(t,i){typeof Ht=="object"&&typeof Rt<"u"?Rt.exports=i():typeof define=="function"&&define.amd?define(i):(t=typeof globalThis<"u"?globalThis:t||self).dayjs_plugin_customParseFormat=i()})(Ht,(function(){"use strict";var t={LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},i=/(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g,s=/\d/,a=/\d\d/,n=/\d\d?/,l=/\d*[^-_:/,()\s\d]+/,k={},S=function(x){return(x=+x)+(x>68?1900:2e3)},w=function(x){return function(y){this[x]=+y}},L=[/[+-]\d\d:?(\d\d)?|Z/,function(x){(this.zone||(this.zone={})).offset=(function(y){if(!y||y==="Z")return 0;var O=y.match(/([+-]|\d\d)/g),A=60*O[1]+(+O[2]||0);return A===0?0:O[0]==="+"?-A:A})(x)}],E=function(x){var y=k[x];return y&&(y.indexOf?y:y.s.concat(y.f))},V=function(x,y){var O,A=k.meridiem;if(A){for(var H=1;H<=24;H+=1)if(x.indexOf(A(H,0,y))>-1){O=H>12;break}}else O=x===(y?"pm":"PM");return O},I={A:[l,function(x){this.afternoon=V(x,!1)}],a:[l,function(x){this.afternoon=V(x,!0)}],Q:[s,function(x){this.month=3*(x-1)+1}],S:[s,function(x){this.milliseconds=100*+x}],SS:[a,function(x){this.milliseconds=10*+x}],SSS:[/\d{3}/,function(x){this.milliseconds=+x}],s:[n,w("seconds")],ss:[n,w("seconds")],m:[n,w("minutes")],mm:[n,w("minutes")],H:[n,w("hours")],h:[n,w("hours")],HH:[n,w("hours")],hh:[n,w("hours")],D:[n,w("day")],DD:[a,w("day")],Do:[l,function(x){var y=k.ordinal,O=x.match(/\d+/);if(this.day=O[0],y)for(var A=1;A<=31;A+=1)y(A).replace(/\[|\]/g,"")===x&&(this.day=A)}],w:[n,w("week")],ww:[a,w("week")],M:[n,w("month")],MM:[a,w("month")],MMM:[l,function(x){var y=E("months"),O=(E("monthsShort")||y.map((function(A){return A.slice(0,3)}))).indexOf(x)+1;if(O<1)throw new Error;this.month=O%12||O}],MMMM:[l,function(x){var y=E("months").indexOf(x)+1;if(y<1)throw new Error;this.month=y%12||y}],Y:[/[+-]?\d+/,w("year")],YY:[a,function(x){this.year=S(x)}],YYYY:[/\d{4}/,w("year")],Z:L,ZZ:L};function M(x){var y,O;y=x,O=k&&k.formats;for(var A=(x=y.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g,(function($,f,p){var v=p&&p.toUpperCase();return f||O[p]||t[p]||O[v].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g,(function(g,T,o){return T||o.slice(1)}))}))).match(i),H=A.length,R=0;R<H;R+=1){var Y=A[R],b=I[Y],u=b&&b[0],C=b&&b[1];A[R]=C?{regex:u,parser:C}:Y.replace(/^\[|\]$/g,"")}return function($){for(var f={},p=0,v=0;p<H;p+=1){var g=A[p];if(typeof g=="string")v+=g.length;else{var T=g.regex,o=g.parser,d=$.slice(v),h=T.exec(d)[0];o.call(f,h),$=$.replace(h,"")}}return(function(m){var _=m.afternoon;if(_!==void 0){var r=m.hours;_?r<12&&(m.hours+=12):r===12&&(m.hours=0),delete m.afternoon}})(f),f}}return function(x,y,O){O.p.customParseFormat=!0,x&&x.parseTwoDigitYear&&(S=x.parseTwoDigitYear);var A=y.prototype,H=A.parse;A.parse=function(R){var Y=R.date,b=R.utc,u=R.args;this.$u=b;var C=u[1];if(typeof C=="string"){var $=u[2]===!0,f=u[3]===!0,p=$||f,v=u[2];f&&(v=u[2]),k=this.$locale(),!$&&v&&(k=O.Ls[v]),this.$d=(function(d,h,m,_){try{if(["x","X"].indexOf(h)>-1)return new Date((h==="X"?1e3:1)*d);var r=M(h)(d),z=r.year,e=r.month,D=r.day,P=r.hours,F=r.minutes,W=r.seconds,j=r.milliseconds,N=r.zone,B=r.week,U=new Date,rt=D||(z||e?1:U.getDate()),nt=z||U.getFullYear(),lt=0;z&&!e||(lt=e>0?e-1:U.getMonth());var ut,dt=P||0,G=F||0,st=W||0,K=j||0;return N?new Date(Date.UTC(nt,lt,rt,dt,G,st,K+60*N.offset*1e3)):m?new Date(Date.UTC(nt,lt,rt,dt,G,st,K)):(ut=new Date(nt,lt,rt,dt,G,st,K),B&&(ut=_(ut).week(B).toDate()),ut)}catch{return new Date("")}})(Y,C,b,O),this.init(),v&&v!==!0&&(this.$L=this.locale(v).$L),p&&Y!=this.format(C)&&(this.$d=new Date("")),k={}}else if(C instanceof Array)for(var g=C.length,T=1;T<=g;T+=1){u[1]=C[T-1];var o=O.apply(this,u);if(o.isValid()){this.$d=o.$d,this.$L=o.$L,this.init();break}T===g&&(this.$d=new Date(""))}else H.call(this,R)}}}))});var Pe=xt((Bt,jt)=>{(function(t,i){typeof Bt=="object"&&typeof jt<"u"?jt.exports=i():typeof define=="function"&&define.amd?define(i):(t=typeof globalThis<"u"?globalThis:t||self).dayjs_plugin_advancedFormat=i()})(Bt,(function(){"use strict";return function(t,i){var s=i.prototype,a=s.format;s.format=function(n){var l=this,k=this.$locale();if(!this.isValid())return a.bind(this)(n);var S=this.$utils(),w=(n||"YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g,(function(L){switch(L){case"Q":return Math.ceil((l.$M+1)/3);case"Do":return k.ordinal(l.$D);case"gggg":return l.weekYear();case"GGGG":return l.isoWeekYear();case"wo":return k.ordinal(l.week(),"W");case"w":case"ww":return S.s(l.week(),L==="w"?1:2,"0");case"W":case"WW":return S.s(l.isoWeek(),L==="W"?1:2,"0");case"k":case"kk":return S.s(String(l.$H===0?24:l.$H),L==="k"?1:2,"0");case"X":return Math.floor(l.$d.getTime()/1e3);case"x":return l.$d.getTime();case"z":return"["+l.offsetName()+"]";case"zzz":return"["+l.offsetName("long")+"]";default:return L}}));return a.bind(this)(w)}}}))});var ze=xt((Gt,Xt)=>{(function(t,i){typeof Gt=="object"&&typeof Xt<"u"?Xt.exports=i():typeof define=="function"&&define.amd?define(i):(t=typeof globalThis<"u"?globalThis:t||self).dayjs_plugin_duration=i()})(Gt,(function(){"use strict";var t,i,s=1e3,a=6e4,n=36e5,l=864e5,k=31536e6,S=2628e6,w=/^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/,L=/\[([^\]]+)]|YYYY|YY|Y|M{1,2}|D{1,2}|H{1,2}|m{1,2}|s{1,2}|SSS/g,E={years:k,months:S,days:l,hours:n,minutes:a,seconds:s,milliseconds:1,weeks:6048e5},V=function(Y){return Y instanceof H},I=function(Y,b,u){return new H(Y,u,b.$l)},M=function(Y){return i.p(Y)+"s"},x=function(Y){return Y<0},y=function(Y){return x(Y)?Math.ceil(Y):Math.floor(Y)},O=function(Y){return Math.abs(Y)},A=function(Y,b){return Y?x(Y)?{negative:!0,format:""+O(Y)+b}:{negative:!1,format:""+Y+b}:{negative:!1,format:""}},H=(function(){function Y(u,C,$){var f=this;if(this.$d={},this.$l=$,u===void 0&&(this.$ms=0,this.parseFromMilliseconds()),C)return I(u*E[M(C)],this);if(typeof u=="number")return this.$ms=u,this.parseFromMilliseconds(),this;if(typeof u=="object")return Object.keys(u).forEach((function(g){f.$d[M(g)]=u[g]})),this.calMilliseconds(),this;if(typeof u=="string"){var p=u.match(w);if(p){var v=p.slice(2).map((function(g){return g!=null?Number(g):0}));return this.$d.years=v[0],this.$d.months=v[1],this.$d.weeks=v[2],this.$d.days=v[3],this.$d.hours=v[4],this.$d.minutes=v[5],this.$d.seconds=v[6],this.calMilliseconds(),this}}return this}var b=Y.prototype;return b.calMilliseconds=function(){var u=this;this.$ms=Object.keys(this.$d).reduce((function(C,$){return C+(u.$d[$]||0)*E[$]}),0)},b.parseFromMilliseconds=function(){var u=this.$ms;this.$d.years=y(u/k),u%=k,this.$d.months=y(u/S),u%=S,this.$d.days=y(u/l),u%=l,this.$d.hours=y(u/n),u%=n,this.$d.minutes=y(u/a),u%=a,this.$d.seconds=y(u/s),u%=s,this.$d.milliseconds=u},b.toISOString=function(){var u=A(this.$d.years,"Y"),C=A(this.$d.months,"M"),$=+this.$d.days||0;this.$d.weeks&&($+=7*this.$d.weeks);var f=A($,"D"),p=A(this.$d.hours,"H"),v=A(this.$d.minutes,"M"),g=this.$d.seconds||0;this.$d.milliseconds&&(g+=this.$d.milliseconds/1e3,g=Math.round(1e3*g)/1e3);var T=A(g,"S"),o=u.negative||C.negative||f.negative||p.negative||v.negative||T.negative,d=p.format||v.format||T.format?"T":"",h=(o?"-":"")+"P"+u.format+C.format+f.format+d+p.format+v.format+T.format;return h==="P"||h==="-P"?"P0D":h},b.toJSON=function(){return this.toISOString()},b.format=function(u){var C=u||"YYYY-MM-DDTHH:mm:ss",$={Y:this.$d.years,YY:i.s(this.$d.years,2,"0"),YYYY:i.s(this.$d.years,4,"0"),M:this.$d.months,MM:i.s(this.$d.months,2,"0"),D:this.$d.days,DD:i.s(this.$d.days,2,"0"),H:this.$d.hours,HH:i.s(this.$d.hours,2,"0"),m:this.$d.minutes,mm:i.s(this.$d.minutes,2,"0"),s:this.$d.seconds,ss:i.s(this.$d.seconds,2,"0"),SSS:i.s(this.$d.milliseconds,3,"0")};return C.replace(L,(function(f,p){return p||String($[f])}))},b.as=function(u){return this.$ms/E[M(u)]},b.get=function(u){var C=this.$ms,$=M(u);return $==="milliseconds"?C%=1e3:C=$==="weeks"?y(C/E[$]):this.$d[$],C||0},b.add=function(u,C,$){var f;return f=C?u*E[M(C)]:V(u)?u.$ms:I(u,this).$ms,I(this.$ms+f*($?-1:1),this)},b.subtract=function(u,C){return this.add(u,C,!0)},b.locale=function(u){var C=this.clone();return C.$l=u,C},b.clone=function(){return I(this.$ms,this)},b.humanize=function(u){return t().add(this.$ms,"ms").locale(this.$l).fromNow(!u)},b.valueOf=function(){return this.asMilliseconds()},b.milliseconds=function(){return this.get("milliseconds")},b.asMilliseconds=function(){return this.as("milliseconds")},b.seconds=function(){return this.get("seconds")},b.asSeconds=function(){return this.as("seconds")},b.minutes=function(){return this.get("minutes")},b.asMinutes=function(){return this.as("minutes")},b.hours=function(){return this.get("hours")},b.asHours=function(){return this.as("hours")},b.days=function(){return this.get("days")},b.asDays=function(){return this.as("days")},b.weeks=function(){return this.get("weeks")},b.asWeeks=function(){return this.as("weeks")},b.months=function(){return this.get("months")},b.asMonths=function(){return this.as("months")},b.years=function(){return this.get("years")},b.asYears=function(){return this.as("years")},Y})(),R=function(Y,b,u){return Y.add(b.years()*u,"y").add(b.months()*u,"M").add(b.days()*u,"d").add(b.hours()*u,"h").add(b.minutes()*u,"m").add(b.seconds()*u,"s").add(b.milliseconds()*u,"ms")};return function(Y,b,u){t=u,i=u().$utils(),u.duration=function(f,p){var v=u.locale();return I(f,{$l:v},p)},u.isDuration=V;var C=b.prototype.add,$=b.prototype.subtract;b.prototype.add=function(f,p){return V(f)?R(this,f,1):C.bind(this)(f,p)},b.prototype.subtract=function(f,p){return V(f)?R(this,f,-1):$.bind(this)(f,p)}}}))});function ni(t){return t}var _t=1,Vt=2,Pt=3,wt=4,$e=1e-6;function si(t){return"translate("+t+",0)"}function ai(t){return"translate(0,"+t+")"}function oi(t){return i=>+t(i)}function ci(t,i){return i=Math.max(0,t.bandwidth()-i*2)/2,t.round()&&(i=Math.round(i)),s=>+t(s)+i}function li(){return!this.__axis}function Fe(t,i){var s=[],a=null,n=null,l=6,k=6,S=3,w=typeof window<"u"&&window.devicePixelRatio>1?0:.5,L=t===_t||t===wt?-1:1,E=t===wt||t===Vt?"x":"y",V=t===_t||t===Pt?si:ai;function I(M){var x=a??(i.ticks?i.ticks.apply(i,s):i.domain()),y=n??(i.tickFormat?i.tickFormat.apply(i,s):ni),O=Math.max(l,0)+S,A=i.range(),H=+A[0]+w,R=+A[A.length-1]+w,Y=(i.bandwidth?ci:oi)(i.copy(),w),b=M.selection?M.selection():M,u=b.selectAll(".domain").data([null]),C=b.selectAll(".tick").data(x,i).order(),$=C.exit(),f=C.enter().append("g").attr("class","tick"),p=C.select("line"),v=C.select("text");u=u.merge(u.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),C=C.merge(f),p=p.merge(f.append("line").attr("stroke","currentColor").attr(E+"2",L*l)),v=v.merge(f.append("text").attr("fill","currentColor").attr(E,L*O).attr("dy",t===_t?"0em":t===Pt?"0.71em":"0.32em")),M!==b&&(u=u.transition(M),C=C.transition(M),p=p.transition(M),v=v.transition(M),$=$.transition(M).attr("opacity",$e).attr("transform",function(g){return isFinite(g=Y(g))?V(g+w):this.getAttribute("transform")}),f.attr("opacity",$e).attr("transform",function(g){var T=this.parentNode.__axis;return V((T&&isFinite(T=T(g))?T:Y(g))+w)})),$.remove(),u.attr("d",t===wt||t===Vt?k?"M"+L*k+","+H+"H"+w+"V"+R+"H"+L*k:"M"+w+","+H+"V"+R:k?"M"+H+","+L*k+"V"+w+"H"+R+"V"+L*k:"M"+H+","+w+"H"+R),C.attr("opacity",1).attr("transform",function(g){return V(Y(g)+w)}),p.attr(E+"2",L*l),v.attr(E,L*O).text(y),b.filter(li).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===Vt?"start":t===wt?"end":"middle"),b.each(function(){this.__axis=Y})}return I.scale=function(M){return arguments.length?(i=M,I):i},I.ticks=function(){return s=Array.from(arguments),I},I.tickArguments=function(M){return arguments.length?(s=M==null?[]:Array.from(M),I):s.slice()},I.tickValues=function(M){return arguments.length?(a=M==null?null:Array.from(M),I):a&&a.slice()},I.tickFormat=function(M){return arguments.length?(n=M,I):n},I.tickSize=function(M){return arguments.length?(l=k=+M,I):l},I.tickSizeInner=function(M){return arguments.length?(l=+M,I):l},I.tickSizeOuter=function(M){return arguments.length?(k=+M,I):k},I.tickPadding=function(M){return arguments.length?(S=+M,I):S},I.offset=function(M){return arguments.length?(w=+M,I):w},I}function Le(t){return Fe(_t,t)}function We(t){return Fe(Pt,t)}var Be=at(ri(),1),Q=at(ue(),1),je=at(Oe(),1),Ge=at(Ve(),1),Xe=at(Pe(),1),ht=at(ue(),1),ii=at(ze(),1);var qt=(function(){var t=c(function(T,o,d,h){for(d=d||{},h=T.length;h--;d[T[h]]=o);return d},"o"),i=[6,8,10,12,13,14,15,16,17,18,20,21,22,23,24,25,26,27,28,29,30,31,33,35,36,38,40],s=[1,26],a=[1,27],n=[1,28],l=[1,29],k=[1,30],S=[1,31],w=[1,32],L=[1,33],E=[1,34],V=[1,9],I=[1,10],M=[1,11],x=[1,12],y=[1,13],O=[1,14],A=[1,15],H=[1,16],R=[1,19],Y=[1,20],b=[1,21],u=[1,22],C=[1,23],$=[1,25],f=[1,35],p={trace:c(function(){},"trace"),yy:{},symbols_:{error:2,start:3,gantt:4,document:5,EOF:6,line:7,SPACE:8,statement:9,NL:10,weekday:11,weekday_monday:12,weekday_tuesday:13,weekday_wednesday:14,weekday_thursday:15,weekday_friday:16,weekday_saturday:17,weekday_sunday:18,weekend:19,weekend_friday:20,weekend_saturday:21,dateFormat:22,inclusiveEndDates:23,topAxis:24,axisFormat:25,tickInterval:26,excludes:27,includes:28,todayMarker:29,title:30,acc_title:31,acc_title_value:32,acc_descr:33,acc_descr_value:34,acc_descr_multiline_value:35,section:36,clickStatement:37,taskTxt:38,taskData:39,click:40,callbackname:41,callbackargs:42,href:43,clickStatementDebug:44,$accept:0,$end:1},terminals_:{2:"error",4:"gantt",6:"EOF",8:"SPACE",10:"NL",12:"weekday_monday",13:"weekday_tuesday",14:"weekday_wednesday",15:"weekday_thursday",16:"weekday_friday",17:"weekday_saturday",18:"weekday_sunday",20:"weekend_friday",21:"weekend_saturday",22:"dateFormat",23:"inclusiveEndDates",24:"topAxis",25:"axisFormat",26:"tickInterval",27:"excludes",28:"includes",29:"todayMarker",30:"title",31:"acc_title",32:"acc_title_value",33:"acc_descr",34:"acc_descr_value",35:"acc_descr_multiline_value",36:"section",38:"taskTxt",39:"taskData",40:"click",41:"callbackname",42:"callbackargs",43:"href"},productions_:[0,[3,3],[5,0],[5,2],[7,2],[7,1],[7,1],[7,1],[11,1],[11,1],[11,1],[11,1],[11,1],[11,1],[11,1],[19,1],[19,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,2],[9,2],[9,1],[9,1],[9,1],[9,2],[37,2],[37,3],[37,3],[37,4],[37,3],[37,4],[37,2],[44,2],[44,3],[44,3],[44,4],[44,3],[44,4],[44,2]],performAction:c(function(o,d,h,m,_,r,z){var e=r.length-1;switch(_){case 1:return r[e-1];case 2:this.$=[];break;case 3:r[e-1].push(r[e]),this.$=r[e-1];break;case 4:case 5:this.$=r[e];break;case 6:case 7:this.$=[];break;case 8:m.setWeekday("monday");break;case 9:m.setWeekday("tuesday");break;case 10:m.setWeekday("wednesday");break;case 11:m.setWeekday("thursday");break;case 12:m.setWeekday("friday");break;case 13:m.setWeekday("saturday");break;case 14:m.setWeekday("sunday");break;case 15:m.setWeekend("friday");break;case 16:m.setWeekend("saturday");break;case 17:m.setDateFormat(r[e].substr(11)),this.$=r[e].substr(11);break;case 18:m.enableInclusiveEndDates(),this.$=r[e].substr(18);break;case 19:m.TopAxis(),this.$=r[e].substr(8);break;case 20:m.setAxisFormat(r[e].substr(11)),this.$=r[e].substr(11);break;case 21:m.setTickInterval(r[e].substr(13)),this.$=r[e].substr(13);break;case 22:m.setExcludes(r[e].substr(9)),this.$=r[e].substr(9);break;case 23:m.setIncludes(r[e].substr(9)),this.$=r[e].substr(9);break;case 24:m.setTodayMarker(r[e].substr(12)),this.$=r[e].substr(12);break;case 27:m.setDiagramTitle(r[e].substr(6)),this.$=r[e].substr(6);break;case 28:this.$=r[e].trim(),m.setAccTitle(this.$);break;case 29:case 30:this.$=r[e].trim(),m.setAccDescription(this.$);break;case 31:m.addSection(r[e].substr(8)),this.$=r[e].substr(8);break;case 33:m.addTask(r[e-1],r[e]),this.$="task";break;case 34:this.$=r[e-1],m.setClickEvent(r[e-1],r[e],null);break;case 35:this.$=r[e-2],m.setClickEvent(r[e-2],r[e-1],r[e]);break;case 36:this.$=r[e-2],m.setClickEvent(r[e-2],r[e-1],null),m.setLink(r[e-2],r[e]);break;case 37:this.$=r[e-3],m.setClickEvent(r[e-3],r[e-2],r[e-1]),m.setLink(r[e-3],r[e]);break;case 38:this.$=r[e-2],m.setClickEvent(r[e-2],r[e],null),m.setLink(r[e-2],r[e-1]);break;case 39:this.$=r[e-3],m.setClickEvent(r[e-3],r[e-1],r[e]),m.setLink(r[e-3],r[e-2]);break;case 40:this.$=r[e-1],m.setLink(r[e-1],r[e]);break;case 41:case 47:this.$=r[e-1]+" "+r[e];break;case 42:case 43:case 45:this.$=r[e-2]+" "+r[e-1]+" "+r[e];break;case 44:case 46:this.$=r[e-3]+" "+r[e-2]+" "+r[e-1]+" "+r[e];break}},"anonymous"),table:[{3:1,4:[1,2]},{1:[3]},t(i,[2,2],{5:3}),{6:[1,4],7:5,8:[1,6],9:7,10:[1,8],11:17,12:s,13:a,14:n,15:l,16:k,17:S,18:w,19:18,20:L,21:E,22:V,23:I,24:M,25:x,26:y,27:O,28:A,29:H,30:R,31:Y,33:b,35:u,36:C,37:24,38:$,40:f},t(i,[2,7],{1:[2,1]}),t(i,[2,3]),{9:36,11:17,12:s,13:a,14:n,15:l,16:k,17:S,18:w,19:18,20:L,21:E,22:V,23:I,24:M,25:x,26:y,27:O,28:A,29:H,30:R,31:Y,33:b,35:u,36:C,37:24,38:$,40:f},t(i,[2,5]),t(i,[2,6]),t(i,[2,17]),t(i,[2,18]),t(i,[2,19]),t(i,[2,20]),t(i,[2,21]),t(i,[2,22]),t(i,[2,23]),t(i,[2,24]),t(i,[2,25]),t(i,[2,26]),t(i,[2,27]),{32:[1,37]},{34:[1,38]},t(i,[2,30]),t(i,[2,31]),t(i,[2,32]),{39:[1,39]},t(i,[2,8]),t(i,[2,9]),t(i,[2,10]),t(i,[2,11]),t(i,[2,12]),t(i,[2,13]),t(i,[2,14]),t(i,[2,15]),t(i,[2,16]),{41:[1,40],43:[1,41]},t(i,[2,4]),t(i,[2,28]),t(i,[2,29]),t(i,[2,33]),t(i,[2,34],{42:[1,42],43:[1,43]}),t(i,[2,40],{41:[1,44]}),t(i,[2,35],{43:[1,45]}),t(i,[2,36]),t(i,[2,38],{42:[1,46]}),t(i,[2,37]),t(i,[2,39])],defaultActions:{},parseError:c(function(o,d){if(d.recoverable)this.trace(o);else{var h=new Error(o);throw h.hash=d,h}},"parseError"),parse:c(function(o){var d=this,h=[0],m=[],_=[null],r=[],z=this.table,e="",D=0,P=0,F=0,W=2,j=1,N=r.slice.call(arguments,1),B=Object.create(this.lexer),U={yy:{}};for(var rt in this.yy)Object.prototype.hasOwnProperty.call(this.yy,rt)&&(U.yy[rt]=this.yy[rt]);B.setInput(o,U.yy),U.yy.lexer=B,U.yy.parser=this,typeof B.yylloc>"u"&&(B.yylloc={});var nt=B.yylloc;r.push(nt);var lt=B.options&&B.options.ranges;typeof U.yy.parseError=="function"?this.parseError=U.yy.parseError:this.parseError=Object.getPrototypeOf(this).parseError;function ut(Z){h.length=h.length-2*Z,_.length=_.length-Z,r.length=r.length-Z}c(ut,"popStack");function dt(){var Z;return Z=m.pop()||B.lex()||j,typeof Z!="number"&&(Z instanceof Array&&(m=Z,Z=m.pop()),Z=d.symbols_[Z]||Z),Z}c(dt,"lex");for(var G,st,K,q,Ji,Et,ft={},bt,tt,le,Tt;;){if(K=h[h.length-1],this.defaultActions[K]?q=this.defaultActions[K]:((G===null||typeof G>"u")&&(G=dt()),q=z[K]&&z[K][G]),typeof q>"u"||!q.length||!q[0]){var Yt="";Tt=[];for(bt in z[K])this.terminals_[bt]&&bt>W&&Tt.push("'"+this.terminals_[bt]+"'");B.showPosition?Yt="Parse error on line "+(D+1)+`:
`+B.showPosition()+`
Expecting `+Tt.join(", ")+", got '"+(this.terminals_[G]||G)+"'":Yt="Parse error on line "+(D+1)+": Unexpected "+(G==j?"end of input":"'"+(this.terminals_[G]||G)+"'"),this.parseError(Yt,{text:B.match,token:this.terminals_[G]||G,line:B.yylineno,loc:nt,expected:Tt})}if(q[0]instanceof Array&&q.length>1)throw new Error("Parse Error: multiple actions possible at state: "+K+", token: "+G);switch(q[0]){case 1:h.push(G),_.push(B.yytext),r.push(B.yylloc),h.push(q[1]),G=null,st?(G=st,st=null):(P=B.yyleng,e=B.yytext,D=B.yylineno,nt=B.yylloc,F>0&&F--);break;case 2:if(tt=this.productions_[q[1]][1],ft.$=_[_.length-tt],ft._$={first_line:r[r.length-(tt||1)].first_line,last_line:r[r.length-1].last_line,first_column:r[r.length-(tt||1)].first_column,last_column:r[r.length-1].last_column},lt&&(ft._$.range=[r[r.length-(tt||1)].range[0],r[r.length-1].range[1]]),Et=this.performAction.apply(ft,[e,P,D,U.yy,q[1],_,r].concat(N)),typeof Et<"u")return Et;tt&&(h=h.slice(0,-1*tt*2),_=_.slice(0,-1*tt),r=r.slice(0,-1*tt)),h.push(this.productions_[q[1]][0]),_.push(ft.$),r.push(ft._$),le=z[h[h.length-2]][h[h.length-1]],h.push(le);break;case 3:return!0}}return!0},"parse")},v=(function(){var T={EOF:1,parseError:c(function(d,h){if(this.yy.parser)this.yy.parser.parseError(d,h);else throw new Error(d)},"parseError"),setInput:c(function(o,d){return this.yy=d||this.yy||{},this._input=o,this._more=this._backtrack=this.done=!1,this.yylineno=this.yyleng=0,this.yytext=this.matched=this.match="",this.conditionStack=["INITIAL"],this.yylloc={first_line:1,first_column:0,last_line:1,last_column:0},this.options.ranges&&(this.yylloc.range=[0,0]),this.offset=0,this},"setInput"),input:c(function(){var o=this._input[0];this.yytext+=o,this.yyleng++,this.offset++,this.match+=o,this.matched+=o;var d=o.match(/(?:\r\n?|\n).*/g);return d?(this.yylineno++,this.yylloc.last_line++):this.yylloc.last_column++,this.options.ranges&&this.yylloc.range[1]++,this._input=this._input.slice(1),o},"input"),unput:c(function(o){var d=o.length,h=o.split(/(?:\r\n?|\n)/g);this._input=o+this._input,this.yytext=this.yytext.substr(0,this.yytext.length-d),this.offset-=d;var m=this.match.split(/(?:\r\n?|\n)/g);this.match=this.match.substr(0,this.match.length-1),this.matched=this.matched.substr(0,this.matched.length-1),h.length-1&&(this.yylineno-=h.length-1);var _=this.yylloc.range;return this.yylloc={first_line:this.yylloc.first_line,last_line:this.yylineno+1,first_column:this.yylloc.first_column,last_column:h?(h.length===m.length?this.yylloc.first_column:0)+m[m.length-h.length].length-h[0].length:this.yylloc.first_column-d},this.options.ranges&&(this.yylloc.range=[_[0],_[0]+this.yyleng-d]),this.yyleng=this.yytext.length,this},"unput"),more:c(function(){return this._more=!0,this},"more"),reject:c(function(){if(this.options.backtrack_lexer)this._backtrack=!0;else return this.parseError("Lexical error on line "+(this.yylineno+1)+`. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
`+this.showPosition(),{text:"",token:null,line:this.yylineno});return this},"reject"),less:c(function(o){this.unput(this.match.slice(o))},"less"),pastInput:c(function(){var o=this.matched.substr(0,this.matched.length-this.match.length);return(o.length>20?"...":"")+o.substr(-20).replace(/\n/g,"")},"pastInput"),upcomingInput:c(function(){var o=this.match;return o.length<20&&(o+=this._input.substr(0,20-o.length)),(o.substr(0,20)+(o.length>20?"...":"")).replace(/\n/g,"")},"upcomingInput"),showPosition:c(function(){var o=this.pastInput(),d=new Array(o.length+1).join("-");return o+this.upcomingInput()+`
`+d+"^"},"showPosition"),test_match:c(function(o,d){var h,m,_;if(this.options.backtrack_lexer&&(_={yylineno:this.yylineno,yylloc:{first_line:this.yylloc.first_line,last_line:this.last_line,first_column:this.yylloc.first_column,last_column:this.yylloc.last_column},yytext:this.yytext,match:this.match,matches:this.matches,matched:this.matched,yyleng:this.yyleng,offset:this.offset,_more:this._more,_input:this._input,yy:this.yy,conditionStack:this.conditionStack.slice(0),done:this.done},this.options.ranges&&(_.yylloc.range=this.yylloc.range.slice(0))),m=o[0].match(/(?:\r\n?|\n).*/g),m&&(this.yylineno+=m.length),this.yylloc={first_line:this.yylloc.last_line,last_line:this.yylineno+1,first_column:this.yylloc.last_column,last_column:m?m[m.length-1].length-m[m.length-1].match(/\r?\n?/)[0].length:this.yylloc.last_column+o[0].length},this.yytext+=o[0],this.match+=o[0],this.matches=o,this.yyleng=this.yytext.length,this.options.ranges&&(this.yylloc.range=[this.offset,this.offset+=this.yyleng]),this._more=!1,this._backtrack=!1,this._input=this._input.slice(o[0].length),this.matched+=o[0],h=this.performAction.call(this,this.yy,this,d,this.conditionStack[this.conditionStack.length-1]),this.done&&this._input&&(this.done=!1),h)return h;if(this._backtrack){for(var r in _)this[r]=_[r];return!1}return!1},"test_match"),next:c(function(){if(this.done)return this.EOF;this._input||(this.done=!0);var o,d,h,m;this._more||(this.yytext="",this.match="");for(var _=this._currentRules(),r=0;r<_.length;r++)if(h=this._input.match(this.rules[_[r]]),h&&(!d||h[0].length>d[0].length)){if(d=h,m=r,this.options.backtrack_lexer){if(o=this.test_match(h,_[r]),o!==!1)return o;if(this._backtrack){d=!1;continue}else return!1}else if(!this.options.flex)break}return d?(o=this.test_match(d,_[m]),o!==!1?o:!1):this._input===""?this.EOF:this.parseError("Lexical error on line "+(this.yylineno+1)+`. Unrecognized text.
`+this.showPosition(),{text:"",token:null,line:this.yylineno})},"next"),lex:c(function(){var d=this.next();return d||this.lex()},"lex"),begin:c(function(d){this.conditionStack.push(d)},"begin"),popState:c(function(){var d=this.conditionStack.length-1;return d>0?this.conditionStack.pop():this.conditionStack[0]},"popState"),_currentRules:c(function(){return this.conditionStack.length&&this.conditionStack[this.conditionStack.length-1]?this.conditions[this.conditionStack[this.conditionStack.length-1]].rules:this.conditions.INITIAL.rules},"_currentRules"),topState:c(function(d){return d=this.conditionStack.length-1-Math.abs(d||0),d>=0?this.conditionStack[d]:"INITIAL"},"topState"),pushState:c(function(d){this.begin(d)},"pushState"),stateStackSize:c(function(){return this.conditionStack.length},"stateStackSize"),options:{"case-insensitive":!0},performAction:c(function(d,h,m,_){var r=_;switch(m){case 0:return this.begin("open_directive"),"open_directive";break;case 1:return this.begin("acc_title"),31;break;case 2:return this.popState(),"acc_title_value";break;case 3:return this.begin("acc_descr"),33;break;case 4:return this.popState(),"acc_descr_value";break;case 5:this.begin("acc_descr_multiline");break;case 6:this.popState();break;case 7:return"acc_descr_multiline_value";case 8:break;case 9:break;case 10:break;case 11:return 10;case 12:break;case 13:break;case 14:this.begin("href");break;case 15:this.popState();break;case 16:return 43;case 17:this.begin("callbackname");break;case 18:this.popState();break;case 19:this.popState(),this.begin("callbackargs");break;case 20:return 41;case 21:this.popState();break;case 22:return 42;case 23:this.begin("click");break;case 24:this.popState();break;case 25:return 40;case 26:return 4;case 27:return 22;case 28:return 23;case 29:return 24;case 30:return 25;case 31:return 26;case 32:return 28;case 33:return 27;case 34:return 29;case 35:return 12;case 36:return 13;case 37:return 14;case 38:return 15;case 39:return 16;case 40:return 17;case 41:return 18;case 42:return 20;case 43:return 21;case 44:return"date";case 45:return 30;case 46:return"accDescription";case 47:return 36;case 48:return 38;case 49:return 39;case 50:return":";case 51:return 6;case 52:return"INVALID"}},"anonymous"),rules:[/^(?:%%\{)/i,/^(?:accTitle\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*\{\s*)/i,/^(?:[\}])/i,/^(?:[^\}]*)/i,/^(?:%%(?!\{)*[^\n]*)/i,/^(?:[^\}]%%*[^\n]*)/i,/^(?:%%*[^\n]*[\n]*)/i,/^(?:[\n]+)/i,/^(?:\s+)/i,/^(?:%[^\n]*)/i,/^(?:href[\s]+["])/i,/^(?:["])/i,/^(?:[^"]*)/i,/^(?:call[\s]+)/i,/^(?:\([\s]*\))/i,/^(?:\()/i,/^(?:[^(]*)/i,/^(?:\))/i,/^(?:[^)]*)/i,/^(?:click[\s]+)/i,/^(?:[\s\n])/i,/^(?:[^\s\n]*)/i,/^(?:gantt\b)/i,/^(?:dateFormat\s[^#\n;]+)/i,/^(?:inclusiveEndDates\b)/i,/^(?:topAxis\b)/i,/^(?:axisFormat\s[^#\n;]+)/i,/^(?:tickInterval\s[^#\n;]+)/i,/^(?:includes\s[^#\n;]+)/i,/^(?:excludes\s[^#\n;]+)/i,/^(?:todayMarker\s[^\n;]+)/i,/^(?:weekday\s+monday\b)/i,/^(?:weekday\s+tuesday\b)/i,/^(?:weekday\s+wednesday\b)/i,/^(?:weekday\s+thursday\b)/i,/^(?:weekday\s+friday\b)/i,/^(?:weekday\s+saturday\b)/i,/^(?:weekday\s+sunday\b)/i,/^(?:weekend\s+friday\b)/i,/^(?:weekend\s+saturday\b)/i,/^(?:\d\d\d\d-\d\d-\d\d\b)/i,/^(?:title\s[^\n]+)/i,/^(?:accDescription\s[^#\n;]+)/i,/^(?:section\s[^\n]+)/i,/^(?:[^:\n]+)/i,/^(?::[^#\n;]+)/i,/^(?::)/i,/^(?:$)/i,/^(?:.)/i],conditions:{acc_descr_multiline:{rules:[6,7],inclusive:!1},acc_descr:{rules:[4],inclusive:!1},acc_title:{rules:[2],inclusive:!1},callbackargs:{rules:[21,22],inclusive:!1},callbackname:{rules:[18,19,20],inclusive:!1},href:{rules:[15,16],inclusive:!1},click:{rules:[24,25],inclusive:!1},INITIAL:{rules:[0,1,3,5,8,9,10,11,12,13,14,17,23,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52],inclusive:!0}}};return T})();p.lexer=v;function g(){this.yy={}}return c(g,"Parser"),g.prototype=p,p.Parser=g,new g})();qt.parser=qt;var ui=qt;Q.default.extend(je.default);Q.default.extend(Ge.default);Q.default.extend(Xe.default);var Ne={friday:5,saturday:6},J="",Jt="",te=void 0,ee="",gt=[],pt=[],ie=new Map,re=[],Mt=[],kt="",ne="",Ue=["active","done","crit","milestone","vert"],se=[],vt=!1,ae=!1,oe="sunday",Ct="saturday",Zt=0,di=c(function(){re=[],Mt=[],kt="",se=[],Dt=0,Kt=void 0,St=void 0,X=[],J="",Jt="",ne="",te=void 0,ee="",gt=[],pt=[],vt=!1,ae=!1,Zt=0,ie=new Map,he(),oe="sunday",Ct="saturday"},"clear"),fi=c(function(t){Jt=t},"setAxisFormat"),hi=c(function(){return Jt},"getAxisFormat"),mi=c(function(t){te=t},"setTickInterval"),ki=c(function(){return te},"getTickInterval"),yi=c(function(t){ee=t},"setTodayMarker"),gi=c(function(){return ee},"getTodayMarker"),pi=c(function(t){J=t},"setDateFormat"),vi=c(function(){vt=!0},"enableInclusiveEndDates"),bi=c(function(){return vt},"endDatesAreInclusive"),Ti=c(function(){ae=!0},"enableTopAxis"),xi=c(function(){return ae},"topAxisEnabled"),wi=c(function(t){ne=t},"setDisplayMode"),_i=c(function(){return ne},"getDisplayMode"),Di=c(function(){return J},"getDateFormat"),Si=c(function(t){gt=t.toLowerCase().split(/[\s,]+/)},"setIncludes"),Mi=c(function(){return gt},"getIncludes"),Ci=c(function(t){pt=t.toLowerCase().split(/[\s,]+/)},"setExcludes"),Ei=c(function(){return pt},"getExcludes"),Yi=c(function(){return ie},"getLinks"),Ii=c(function(t){kt=t,re.push(t)},"addSection"),Ai=c(function(){return re},"getSections"),$i=c(function(){let t=He(),i=10,s=0;for(;!t&&s<i;)t=He(),s++;return Mt=X,Mt},"getTasks"),qe=c(function(t,i,s,a){let n=t.format(i.trim()),l=t.format("YYYY-MM-DD");return a.includes(n)||a.includes(l)?!1:s.includes("weekends")&&(t.isoWeekday()===Ne[Ct]||t.isoWeekday()===Ne[Ct]+1)||s.includes(t.format("dddd").toLowerCase())?!0:s.includes(n)||s.includes(l)},"isInvalidDate"),Fi=c(function(t){oe=t},"setWeekday"),Li=c(function(){return oe},"getWeekday"),Wi=c(function(t){Ct=t},"setWeekend"),Ze=c(function(t,i,s,a){if(!s.length||t.manualEndTime)return;let n;t.startTime instanceof Date?n=(0,Q.default)(t.startTime):n=(0,Q.default)(t.startTime,i,!0),n=n.add(1,"d");let l;t.endTime instanceof Date?l=(0,Q.default)(t.endTime):l=(0,Q.default)(t.endTime,i,!0);let[k,S]=Oi(n,l,i,s,a);t.endTime=k.toDate(),t.renderEndTime=S},"checkTaskDates"),Oi=c(function(t,i,s,a,n){let l=!1,k=null;for(;t<=i;)l||(k=i.toDate()),l=qe(t,s,a,n),l&&(i=i.add(1,"d")),t=t.add(1,"d");return[i,k]},"fixTaskDates"),Qt=c(function(t,i,s){if(s=s.trim(),c(S=>{let w=S.trim();return w==="x"||w==="X"},"isTimestampFormat")(i)&&/^\d+$/.test(s))return new Date(Number(s));let l=/^after\s+(?<ids>[\d\w- ]+)/.exec(s);if(l!==null){let S=null;for(let L of l.groups.ids.split(" ")){let E=ct(L);E!==void 0&&(!S||E.endTime>S.endTime)&&(S=E)}if(S)return S.endTime;let w=new Date;return w.setHours(0,0,0,0),w}let k=(0,Q.default)(s,i.trim(),!0);if(k.isValid())return k.toDate();{it.debug("Invalid date:"+s),it.debug("With date format:"+i.trim());let S=new Date(s);if(S===void 0||isNaN(S.getTime())||S.getFullYear()<-1e4||S.getFullYear()>1e4)throw new Error("Invalid date:"+s);return S}},"getStartDate"),Qe=c(function(t){let i=/^(\d+(?:\.\d+)?)([Mdhmswy]|ms)$/.exec(t.trim());return i!==null?[Number.parseFloat(i[1]),i[2]]:[NaN,"ms"]},"parseDuration"),Ke=c(function(t,i,s,a=!1){s=s.trim();let l=/^until\s+(?<ids>[\d\w- ]+)/.exec(s);if(l!==null){let E=null;for(let I of l.groups.ids.split(" ")){let M=ct(I);M!==void 0&&(!E||M.startTime<E.startTime)&&(E=M)}if(E)return E.startTime;let V=new Date;return V.setHours(0,0,0,0),V}let k=(0,Q.default)(s,i.trim(),!0);if(k.isValid())return a&&(k=k.add(1,"d")),k.toDate();let S=(0,Q.default)(t),[w,L]=Qe(s);if(!Number.isNaN(w)){let E=S.add(w,L);E.isValid()&&(S=E)}return S.toDate()},"getEndDate"),Dt=0,mt=c(function(t){return t===void 0?(Dt=Dt+1,"task"+Dt):t},"parseId"),Vi=c(function(t,i){let s;i.substr(0,1)===":"?s=i.substr(1,i.length):s=i;let a=s.split(","),n={};ce(a,n,Ue);for(let k=0;k<a.length;k++)a[k]=a[k].trim();let l="";switch(a.length){case 1:n.id=mt(),n.startTime=t.endTime,l=a[0];break;case 2:n.id=mt(),n.startTime=Qt(void 0,J,a[0]),l=a[1];break;case 3:n.id=mt(a[0]),n.startTime=Qt(void 0,J,a[1]),l=a[2];break;default:}return l&&(n.endTime=Ke(n.startTime,J,l,vt),n.manualEndTime=(0,Q.default)(l,"YYYY-MM-DD",!0).isValid(),Ze(n,J,pt,gt)),n},"compileData"),Pi=c(function(t,i){let s;i.substr(0,1)===":"?s=i.substr(1,i.length):s=i;let a=s.split(","),n={};ce(a,n,Ue);for(let l=0;l<a.length;l++)a[l]=a[l].trim();switch(a.length){case 1:n.id=mt(),n.startTime={type:"prevTaskEnd",id:t},n.endTime={data:a[0]};break;case 2:n.id=mt(),n.startTime={type:"getStartDate",startData:a[0]},n.endTime={data:a[1]};break;case 3:n.id=mt(a[0]),n.startTime={type:"getStartDate",startData:a[1]},n.endTime={data:a[2]};break;default:}return n},"parseData"),Kt,St,X=[],Je={},zi=c(function(t,i){let s={section:kt,type:kt,processed:!1,manualEndTime:!1,renderEndTime:null,raw:{data:i},task:t,classes:[]},a=Pi(St,i);s.raw.startTime=a.startTime,s.raw.endTime=a.endTime,s.id=a.id,s.prevTaskId=St,s.active=a.active,s.done=a.done,s.crit=a.crit,s.milestone=a.milestone,s.vert=a.vert,s.order=Zt,Zt++;let n=X.push(s);St=s.id,Je[s.id]=n-1},"addTask"),ct=c(function(t){let i=Je[t];return X[i]},"findTaskById"),Ni=c(function(t,i){let s={section:kt,type:kt,description:t,task:t,classes:[]},a=Vi(Kt,i);s.startTime=a.startTime,s.endTime=a.endTime,s.id=a.id,s.active=a.active,s.done=a.done,s.crit=a.crit,s.milestone=a.milestone,s.vert=a.vert,Kt=s,Mt.push(s)},"addTaskOrg"),He=c(function(){let t=c(function(s){let a=X[s],n="";switch(X[s].raw.startTime.type){case"prevTaskEnd":{let l=ct(a.prevTaskId);a.startTime=l.endTime;break}case"getStartDate":n=Qt(void 0,J,X[s].raw.startTime.startData),n&&(X[s].startTime=n);break}return X[s].startTime&&(X[s].endTime=Ke(X[s].startTime,J,X[s].raw.endTime.data,vt),X[s].endTime&&(X[s].processed=!0,X[s].manualEndTime=(0,Q.default)(X[s].raw.endTime.data,"YYYY-MM-DD",!0).isValid(),Ze(X[s],J,pt,gt))),X[s].processed},"compileTask"),i=!0;for(let[s,a]of X.entries())t(s),i=i&&a.processed;return i},"compileTasks"),Hi=c(function(t,i){let s=i;ot().securityLevel!=="loose"&&(s=(0,Be.sanitizeUrl)(i)),t.split(",").forEach(function(a){ct(a)!==void 0&&(ei(a,()=>{window.open(s,"_self")}),ie.set(a,s))}),ti(t,"clickable")},"setLink"),ti=c(function(t,i){t.split(",").forEach(function(s){let a=ct(s);a!==void 0&&a.classes.push(i)})},"setClass"),Ri=c(function(t,i,s){if(ot().securityLevel!=="loose"||i===void 0)return;let a=[];if(typeof s=="string"){a=s.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);for(let l=0;l<a.length;l++){let k=a[l].trim();k.startsWith('"')&&k.endsWith('"')&&(k=k.substr(1,k.length-2)),a[l]=k}}a.length===0&&a.push(t),ct(t)!==void 0&&ei(t,()=>{Ae.runFunc(i,...a)})},"setClickFun"),ei=c(function(t,i){se.push(function(){let s=document.querySelector(`[id="${t}"]`);s!==null&&s.addEventListener("click",function(){i()})},function(){let s=document.querySelector(`[id="${t}-text"]`);s!==null&&s.addEventListener("click",function(){i()})})},"pushFun"),Bi=c(function(t,i,s){t.split(",").forEach(function(a){Ri(a,i,s)}),ti(t,"clickable")},"setClickEvent"),ji=c(function(t){se.forEach(function(i){i(t)})},"bindFunctions"),Gi={getConfig:c(()=>ot().gantt,"getConfig"),clear:di,setDateFormat:pi,getDateFormat:Di,enableInclusiveEndDates:vi,endDatesAreInclusive:bi,enableTopAxis:Ti,topAxisEnabled:xi,setAxisFormat:fi,getAxisFormat:hi,setTickInterval:mi,getTickInterval:ki,setTodayMarker:yi,getTodayMarker:gi,setAccTitle:me,getAccTitle:ke,setDiagramTitle:pe,getDiagramTitle:ve,setDisplayMode:wi,getDisplayMode:_i,setAccDescription:ye,getAccDescription:ge,addSection:Ii,getSections:Ai,getTasks:$i,addTask:zi,findTaskById:ct,addTaskOrg:Ni,setIncludes:Si,getIncludes:Mi,setExcludes:Ci,getExcludes:Ei,setClickEvent:Bi,setLink:Hi,getLinks:Yi,bindFunctions:ji,parseDuration:Qe,isInvalidDate:qe,setWeekday:Fi,getWeekday:Li,setWeekend:Wi};function ce(t,i,s){let a=!0;for(;a;)a=!1,s.forEach(function(n){let l="^\\s*"+n+"\\s*$",k=new RegExp(l);t[0].match(k)&&(i[n]=!0,t.shift(1),a=!0)})}c(ce,"getTaskTags");ht.default.extend(ii.default);var Xi=c(function(){it.debug("Something is calling, setConf, remove the call")},"setConf"),Re={monday:_e,tuesday:De,wednesday:Se,thursday:Me,friday:Ce,saturday:Ee,sunday:we},Ui=c((t,i)=>{let s=[...t].map(()=>-1/0),a=[...t].sort((l,k)=>l.startTime-k.startTime||l.order-k.order),n=0;for(let l of a)for(let k=0;k<s.length;k++)if(l.startTime>=s[k]){s[k]=l.endTime,l.order=k+i,k>n&&(n=k);break}return n},"getMaxIntersections"),et,Ut=1e4,qi=c(function(t,i,s,a){let n=ot().gantt,l=ot().securityLevel,k;l==="sandbox"&&(k=yt("#i"+i));let S=l==="sandbox"?yt(k.nodes()[0].contentDocument.body):yt("body"),w=l==="sandbox"?k.nodes()[0].contentDocument:document,L=w.getElementById(i);et=L.parentElement.offsetWidth,et===void 0&&(et=1200),n.useWidth!==void 0&&(et=n.useWidth);let E=a.db.getTasks(),V=[];for(let f of E)V.push(f.type);V=$(V);let I={},M=2*n.topPadding;if(a.db.getDisplayMode()==="compact"||n.displayMode==="compact"){let f={};for(let v of E)f[v.section]===void 0?f[v.section]=[v]:f[v.section].push(v);let p=0;for(let v of Object.keys(f)){let g=Ui(f[v],p)+1;p+=g,M+=g*(n.barHeight+n.barGap),I[v]=g}}else{M+=E.length*(n.barHeight+n.barGap);for(let f of V)I[f]=E.filter(p=>p.type===f).length}L.setAttribute("viewBox","0 0 "+et+" "+M);let x=S.select(`[id="${i}"]`),y=Ie().domain([Te(E,function(f){return f.startTime}),be(E,function(f){return f.endTime})]).rangeRound([0,et-n.leftPadding-n.rightPadding]);function O(f,p){let v=f.startTime,g=p.startTime,T=0;return v>g?T=1:v<g&&(T=-1),T}c(O,"taskCompare"),E.sort(O),A(E,et,M),fe(x,M,et,n.useMaxWidth),x.append("text").text(a.db.getDiagramTitle()).attr("x",et/2).attr("y",n.titleTopMargin).attr("class","titleText");function A(f,p,v){let g=n.barHeight,T=g+n.barGap,o=n.topPadding,d=n.leftPadding,h=Ye().domain([0,V.length]).range(["#00B9FA","#F95002"]).interpolate(xe);R(T,o,d,p,v,f,a.db.getExcludes(),a.db.getIncludes()),b(d,o,p,v),H(f,T,o,d,g,h,p,v),u(T,o,d,g,h),C(d,o,p,v)}c(A,"makeGantt");function H(f,p,v,g,T,o,d){f.sort((e,D)=>e.vert===D.vert?0:e.vert?1:-1);let m=[...new Set(f.map(e=>e.order))].map(e=>f.find(D=>D.order===e));x.append("g").selectAll("rect").data(m).enter().append("rect").attr("x",0).attr("y",function(e,D){return D=e.order,D*p+v-2}).attr("width",function(){return d-n.rightPadding/2}).attr("height",p).attr("class",function(e){for(let[D,P]of V.entries())if(e.type===P)return"section section"+D%n.numberSectionStyles;return"section section0"}).enter();let _=x.append("g").selectAll("rect").data(f).enter(),r=a.db.getLinks();if(_.append("rect").attr("id",function(e){return e.id}).attr("rx",3).attr("ry",3).attr("x",function(e){return e.milestone?y(e.startTime)+g+.5*(y(e.endTime)-y(e.startTime))-.5*T:y(e.startTime)+g}).attr("y",function(e,D){return D=e.order,e.vert?n.gridLineStartPadding:D*p+v}).attr("width",function(e){return e.milestone?T:e.vert?.08*T:y(e.renderEndTime||e.endTime)-y(e.startTime)}).attr("height",function(e){return e.vert?E.length*(n.barHeight+n.barGap)+n.barHeight*2:T}).attr("transform-origin",function(e,D){return D=e.order,(y(e.startTime)+g+.5*(y(e.endTime)-y(e.startTime))).toString()+"px "+(D*p+v+.5*T).toString()+"px"}).attr("class",function(e){let D="task",P="";e.classes.length>0&&(P=e.classes.join(" "));let F=0;for(let[j,N]of V.entries())e.type===N&&(F=j%n.numberSectionStyles);let W="";return e.active?e.crit?W+=" activeCrit":W=" active":e.done?e.crit?W=" doneCrit":W=" done":e.crit&&(W+=" crit"),W.length===0&&(W=" task"),e.milestone&&(W=" milestone "+W),e.vert&&(W=" vert "+W),W+=F,W+=" "+P,D+W}),_.append("text").attr("id",function(e){return e.id+"-text"}).text(function(e){return e.task}).attr("font-size",n.fontSize).attr("x",function(e){let D=y(e.startTime),P=y(e.renderEndTime||e.endTime);if(e.milestone&&(D+=.5*(y(e.endTime)-y(e.startTime))-.5*T,P=D+T),e.vert)return y(e.startTime)+g;let F=this.getBBox().width;return F>P-D?P+F+1.5*n.leftPadding>d?D+g-5:P+g+5:(P-D)/2+D+g}).attr("y",function(e,D){return e.vert?n.gridLineStartPadding+E.length*(n.barHeight+n.barGap)+60:(D=e.order,D*p+n.barHeight/2+(n.fontSize/2-2)+v)}).attr("text-height",T).attr("class",function(e){let D=y(e.startTime),P=y(e.endTime);e.milestone&&(P=D+T);let F=this.getBBox().width,W="";e.classes.length>0&&(W=e.classes.join(" "));let j=0;for(let[B,U]of V.entries())e.type===U&&(j=B%n.numberSectionStyles);let N="";return e.active&&(e.crit?N="activeCritText"+j:N="activeText"+j),e.done?e.crit?N=N+" doneCritText"+j:N=N+" doneText"+j:e.crit&&(N=N+" critText"+j),e.milestone&&(N+=" milestoneText"),e.vert&&(N+=" vertText"),F>P-D?P+F+1.5*n.leftPadding>d?W+" taskTextOutsideLeft taskTextOutside"+j+" "+N:W+" taskTextOutsideRight taskTextOutside"+j+" "+N+" width-"+F:W+" taskText taskText"+j+" "+N+" width-"+F}),ot().securityLevel==="sandbox"){let e;e=yt("#i"+i);let D=e.nodes()[0].contentDocument;_.filter(function(P){return r.has(P.id)}).each(function(P){var F=D.querySelector("#"+P.id),W=D.querySelector("#"+P.id+"-text");let j=F.parentNode;var N=D.createElement("a");N.setAttribute("xlink:href",r.get(P.id)),N.setAttribute("target","_top"),j.appendChild(N),N.appendChild(F),N.appendChild(W)})}}c(H,"drawRects");function R(f,p,v,g,T,o,d,h){if(d.length===0&&h.length===0)return;let m,_;for(let{startTime:F,endTime:W}of o)(m===void 0||F<m)&&(m=F),(_===void 0||W>_)&&(_=W);if(!m||!_)return;if((0,ht.default)(_).diff((0,ht.default)(m),"year")>5){it.warn("The difference between the min and max time is more than 5 years. This will cause performance issues. Skipping drawing exclude days.");return}let r=a.db.getDateFormat(),z=[],e=null,D=(0,ht.default)(m);for(;D.valueOf()<=_;)a.db.isInvalidDate(D,r,d,h)?e?e.end=D:e={start:D,end:D}:e&&(z.push(e),e=null),D=D.add(1,"d");x.append("g").selectAll("rect").data(z).enter().append("rect").attr("id",F=>"exclude-"+F.start.format("YYYY-MM-DD")).attr("x",F=>y(F.start.startOf("day"))+v).attr("y",n.gridLineStartPadding).attr("width",F=>y(F.end.endOf("day"))-y(F.start.startOf("day"))).attr("height",T-p-n.gridLineStartPadding).attr("transform-origin",function(F,W){return(y(F.start)+v+.5*(y(F.end)-y(F.start))).toString()+"px "+(W*f+.5*T).toString()+"px"}).attr("class","exclude-range")}c(R,"drawExcludeDays");function Y(f,p,v,g){if(v<=0||f>p)return 1/0;let T=p-f,o=ht.default.duration({[g??"day"]:v}).asMilliseconds();return o<=0?1/0:Math.ceil(T/o)}c(Y,"getEstimatedTickCount");function b(f,p,v,g){let T=a.db.getDateFormat(),o=a.db.getAxisFormat(),d;o?d=o:T==="D"?d="%d":d=n.axisFormat??"%Y-%m-%d";let h=We(y).tickSize(-g+p+n.gridLineStartPadding).tickFormat(Ot(d)),_=/^([1-9]\d*)(millisecond|second|minute|hour|day|week|month)$/.exec(a.db.getTickInterval()||n.tickInterval);if(_!==null){let r=parseInt(_[1],10);if(isNaN(r)||r<=0)it.warn(`Invalid tick interval value: "${_[1]}". Skipping custom tick interval.`);else{let z=_[2],e=a.db.getWeekday()||n.weekday,D=y.domain(),P=D[0],F=D[1],W=Y(P,F,r,z);if(W>Ut)it.warn(`The tick interval "${r}${z}" would generate ${W} ticks, which exceeds the maximum allowed (${Ut}). This may indicate an invalid date or time range. Skipping custom tick interval.`);else switch(z){case"millisecond":h.ticks(It.every(r));break;case"second":h.ticks(At.every(r));break;case"minute":h.ticks($t.every(r));break;case"hour":h.ticks(Ft.every(r));break;case"day":h.ticks(Lt.every(r));break;case"week":h.ticks(Re[e].every(r));break;case"month":h.ticks(Wt.every(r));break}}}if(x.append("g").attr("class","grid").attr("transform","translate("+f+", "+(g-50)+")").call(h).selectAll("text").style("text-anchor","middle").attr("fill","#000").attr("stroke","none").attr("font-size",10).attr("dy","1em"),a.db.topAxisEnabled()||n.topAxis){let r=Le(y).tickSize(-g+p+n.gridLineStartPadding).tickFormat(Ot(d));if(_!==null){let z=parseInt(_[1],10);if(isNaN(z)||z<=0)it.warn(`Invalid tick interval value: "${_[1]}". Skipping custom tick interval.`);else{let e=_[2],D=a.db.getWeekday()||n.weekday,P=y.domain(),F=P[0],W=P[1];if(Y(F,W,z,e)<=Ut)switch(e){case"millisecond":r.ticks(It.every(z));break;case"second":r.ticks(At.every(z));break;case"minute":r.ticks($t.every(z));break;case"hour":r.ticks(Ft.every(z));break;case"day":r.ticks(Lt.every(z));break;case"week":r.ticks(Re[D].every(z));break;case"month":r.ticks(Wt.every(z));break}}}x.append("g").attr("class","grid").attr("transform","translate("+f+", "+p+")").call(r).selectAll("text").style("text-anchor","middle").attr("fill","#000").attr("stroke","none").attr("font-size",10)}}c(b,"makeGrid");function u(f,p){let v=0,g=Object.keys(I).map(T=>[T,I[T]]);x.append("g").selectAll("text").data(g).enter().append(function(T){let o=T[0].split(de.lineBreakRegex),d=-(o.length-1)/2,h=w.createElementNS("http://www.w3.org/2000/svg","text");h.setAttribute("dy",d+"em");for(let[m,_]of o.entries()){let r=w.createElementNS("http://www.w3.org/2000/svg","tspan");r.setAttribute("alignment-baseline","central"),r.setAttribute("x","10"),m>0&&r.setAttribute("dy","1em"),r.textContent=_,h.appendChild(r)}return h}).attr("x",10).attr("y",function(T,o){if(o>0)for(let d=0;d<o;d++)return v+=g[o-1][1],T[1]*f/2+v*f+p;else return T[1]*f/2+p}).attr("font-size",n.sectionFontSize).attr("class",function(T){for(let[o,d]of V.entries())if(T[0]===d)return"sectionTitle sectionTitle"+o%n.numberSectionStyles;return"sectionTitle"})}c(u,"vertLabels");function C(f,p,v,g){let T=a.db.getTodayMarker();if(T==="off")return;let o=x.append("g").attr("class","today"),d=new Date,h=o.append("line");h.attr("x1",y(d)+f).attr("x2",y(d)+f).attr("y1",n.titleTopMargin).attr("y2",g-n.titleTopMargin).attr("class","today"),T!==""&&h.attr("style",T.replace(/,/g,";"))}c(C,"drawToday");function $(f){let p={},v=[];for(let g=0,T=f.length;g<T;++g)Object.prototype.hasOwnProperty.call(p,f[g])||(p[f[g]]=!0,v.push(f[g]));return v}c($,"checkUnique")},"draw"),Zi={setConf:Xi,draw:qi},Qi=c(t=>`
  .mermaid-main-font {
        font-family: ${t.fontFamily};
  }

  .exclude-range {
    fill: ${t.excludeBkgColor};
  }

  .section {
    stroke: none;
    opacity: 0.2;
  }

  .section0 {
    fill: ${t.sectionBkgColor};
  }

  .section2 {
    fill: ${t.sectionBkgColor2};
  }

  .section1,
  .section3 {
    fill: ${t.altSectionBkgColor};
    opacity: 0.2;
  }

  .sectionTitle0 {
    fill: ${t.titleColor};
  }

  .sectionTitle1 {
    fill: ${t.titleColor};
  }

  .sectionTitle2 {
    fill: ${t.titleColor};
  }

  .sectionTitle3 {
    fill: ${t.titleColor};
  }

  .sectionTitle {
    text-anchor: start;
    font-family: ${t.fontFamily};
  }


  /* Grid and axis */

  .grid .tick {
    stroke: ${t.gridColor};
    opacity: 0.8;
    shape-rendering: crispEdges;
  }

  .grid .tick text {
    font-family: ${t.fontFamily};
    fill: ${t.textColor};
  }

  .grid path {
    stroke-width: 0;
  }


  /* Today line */

  .today {
    fill: none;
    stroke: ${t.todayLineColor};
    stroke-width: 2px;
  }


  /* Task styling */

  /* Default task */

  .task {
    stroke-width: 2;
  }

  .taskText {
    text-anchor: middle;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideRight {
    fill: ${t.taskTextDarkColor};
    text-anchor: start;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideLeft {
    fill: ${t.taskTextDarkColor};
    text-anchor: end;
  }


  /* Special case clickable */

  .task.clickable {
    cursor: pointer;
  }

  .taskText.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideLeft.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideRight.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }


  /* Specific task settings for the sections*/

  .taskText0,
  .taskText1,
  .taskText2,
  .taskText3 {
    fill: ${t.taskTextColor};
  }

  .task0,
  .task1,
  .task2,
  .task3 {
    fill: ${t.taskBkgColor};
    stroke: ${t.taskBorderColor};
  }

  .taskTextOutside0,
  .taskTextOutside2
  {
    fill: ${t.taskTextOutsideColor};
  }

  .taskTextOutside1,
  .taskTextOutside3 {
    fill: ${t.taskTextOutsideColor};
  }


  /* Active task */

  .active0,
  .active1,
  .active2,
  .active3 {
    fill: ${t.activeTaskBkgColor};
    stroke: ${t.activeTaskBorderColor};
  }

  .activeText0,
  .activeText1,
  .activeText2,
  .activeText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Completed task */

  .done0,
  .done1,
  .done2,
  .done3 {
    stroke: ${t.doneTaskBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
  }

  .doneText0,
  .doneText1,
  .doneText2,
  .doneText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Tasks on the critical line */

  .crit0,
  .crit1,
  .crit2,
  .crit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.critBkgColor};
    stroke-width: 2;
  }

  .activeCrit0,
  .activeCrit1,
  .activeCrit2,
  .activeCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.activeTaskBkgColor};
    stroke-width: 2;
  }

  .doneCrit0,
  .doneCrit1,
  .doneCrit2,
  .doneCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
    cursor: pointer;
    shape-rendering: crispEdges;
  }

  .milestone {
    transform: rotate(45deg) scale(0.8,0.8);
  }

  .milestoneText {
    font-style: italic;
  }
  .doneCritText0,
  .doneCritText1,
  .doneCritText2,
  .doneCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .vert {
    stroke: ${t.vertLineColor};
  }

  .vertText {
    font-size: 15px;
    text-anchor: middle;
    fill: ${t.vertLineColor} !important;
  }

  .activeCritText0,
  .activeCritText1,
  .activeCritText2,
  .activeCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .titleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${t.titleColor||t.textColor};
    font-family: ${t.fontFamily};
  }
`,"getStyles"),Ki=Qi,sr={parser:ui,db:Gi,renderer:Zi,styles:Ki};export{sr as diagram};
